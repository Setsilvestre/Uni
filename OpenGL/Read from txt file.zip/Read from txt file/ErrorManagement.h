#pragma once


using namespace std;
#include <string>

class ErrorManagement
{
public:
	static void errorRunTime(string errorString);
};


